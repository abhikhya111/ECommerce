import './App.css';
import ProductDetails from './components/ProductDetails';
import Header from './Header';
function App() {
 
  return (<>
    <div className='app'>
    <Header/>

      <ProductDetails/>
    </div>
    </>
  );
}

export default App;
