import './App.css';
import ProductDetails from './components/ProductDetails';

function App() {
 
  return (<>
    <div className='app'>
      <ProductDetails/>
    </div>
    </>
  );
}

export default App;
